/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Laundry;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author annisa
 */
public class koneksi {
    static Object koneksi;
    void testkoneksi(){
}
     public static void main(final String[] args){
try {

Class.forName("com.mysql.jdbc.Driver").newInstance();
Connection koneksi = DriverManager.getConnection(
"jdbc:mysql://localhost/laundry", "root", "");
System.out.println("koneksi berhasil");
JOptionPane.showMessageDialog(null," koneksi berhasil ","Informasi", JOptionPane.INFORMATION_MESSAGE);
koneksi.close();
    }catch(Exception e)
    {
        JOptionPane.showMessageDialog(null,"koneksi gagal");

koneksi test = new koneksi();
test.testkoneksi();
System.exit(0);
    }
}
}
