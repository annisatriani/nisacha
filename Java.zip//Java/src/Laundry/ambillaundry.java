/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Laundry;
import java.sql.Connection;
import java.sql.Statement;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author annisa
 */
public class ambillaundry extends javax.swing.JFrame {
    java.util.Date tglsekarang = new java.util.Date();
    private final SimpleDateFormat smpdtfmt = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
    private final String tanggal = smpdtfmt.format(tglsekarang);
    private Statement stat;
    private Connection con;
    private ResultSet res;
    public DefaultTableModel tabmodel;
    public DefaultTableModel tabmodel1;
    public long beratt;
    public long jumlahh;
    public long hargaa;

    private Object displaytext;
    private void koneksi(){
try {
Class.forName("com.mysql.jdbc.Driver");
con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/laundry", "root", "");
stat=(Statement) con.createStatement();
} catch (ClassNotFoundException | SQLException e) {
JOptionPane.showMessageDialog(null, e);
}
}
    /**
     * Creates new form ambillaundry
     */
    public ambillaundry() {
        initComponents();
        koneksi();
        judul();
        tampildata();
        judul1();
        tampildata1();
        tglkeluar.setText(tanggal);
        setJam();
        no_antrian.disable();
    }
    
    public final void setJam(){
ActionListener taskPerformer = (ActionEvent evt) -> {
    String nol_jam = "", nol_menit = "",nol_detik = "";
    java.util.Date dateTime = new java.util.Date();
    int nilai_jam = dateTime.getHours();
    int nilai_menit = dateTime.getMinutes();
    int nilai_detik = dateTime.getSeconds();
    if(nilai_jam <= 9) nol_jam= "0";
    if(nilai_menit <= 9) nol_menit= "0";
    if(nilai_detik <= 9) nol_detik= "0";
    String jam = nol_jam + Integer.toString(nilai_jam);
    String menit = nol_menit + Integer.toString(nilai_menit);
    String detik = nol_detik + Integer.toString(nilai_detik);
    lblwktu.setText(jam+":"+menit+":"+detik+"");
};
new Timer(1000, taskPerformer).start();
}
    
    public void tampildata(){
        try {
            stat = con.createStatement();
            tabmodel.getDataVector().removeAllElements();
            tabmodel.fireTableDataChanged();
            res = stat.executeQuery("SELECT * FROM transaksi");
            while (res.next()) {                
                Object[] data = {
                    res.getString("nomor_antrian"),
                    res.getString("tanggal"),
                    res.getString("jam"),
                    res.getString("nama"),
                    res.getString("parfum"),
                    res.getString("berat"),
                    res.getString("jumlah"),
                    res.getString("harga"),};
                tabmodel.addRow(data);
            }
    } catch (Exception e) {
            e.printStackTrace();
    }
    }

private void judul(){ 
        Object[] judul = {"Nomor Antrian","Tanggal","Jam","Nama","Jenis","Berat","Jumlah","Harga"};
        tabmodel = new DefaultTableModel(null,judul);
        tabel.setModel(tabmodel);
}


public void tampildata1(){
        try {
            stat = con.createStatement();
            tabmodel1.getDataVector().removeAllElements();
            tabmodel1.fireTableDataChanged();
            res = stat.executeQuery("SELECT * FROM ambil");
            while (res.next()) {                
                Object[] data = {
                    res.getString("nomor_antrian"),
                    res.getString("tanggal"),
                    res.getString("jam"),
                    res.getString("nama"),
                    res.getString("parfum"),
                    res.getString("berat"),
                    res.getString("jumlah"),
                    res.getString("harga"),
                    res.getString("tgl_keluar"),
                    res.getString("jam_keluar"),};
                tabmodel1.addRow(data);
            }
    } catch (Exception e) {
            e.printStackTrace();
    }
    }

private void judul1(){ 
        Object[] judul = {"Nomor Antrian","Tanggal","Jam","Nama","Jenis","Berat","Jumlah","Harga","Tanggal Keluar","Jam Keluar"};
        tabmodel1 = new DefaultTableModel(null,judul);
        tabel1.setModel(tabmodel1);
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollBar1 = new javax.swing.JScrollBar();
        jLabel7 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jamm = new javax.swing.JTextField();
        no_antrian = new javax.swing.JTextField();
        tanggall = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        nama = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabel = new javax.swing.JTable();
        jenis = new javax.swing.JComboBox();
        berat = new javax.swing.JTextField();
        jumlah = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        tanggalkeluar = new javax.swing.JTextField();
        jamkeluar = new javax.swing.JLabel();
        tanggalkeluar1 = new javax.swing.JTextField();
        lblwktu = new javax.swing.JLabel();
        tglkeluar = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        harga = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabel1 = new javax.swing.JTable();
        jButton9 = new javax.swing.JButton();

        jLabel7.setText("jLabel7");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(2123, 490));

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel1.setText("PENGAMBILAN LAUNDRY");

        jPanel2.setBackground(new java.awt.Color(255, 153, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setText("Jam");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 97, 28, 24));
        jPanel2.add(jamm, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 99, 213, -1));

        no_antrian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                no_antrianActionPerformed(evt);
            }
        });
        jPanel2.add(no_antrian, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 29, 213, -1));
        jPanel2.add(tanggall, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 64, 213, -1));

        jLabel3.setText("Tanggal");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 62, 88, 24));

        jLabel4.setText("Nama");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 132, 88, 20));

        jLabel5.setText("Nomor Antrian");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 27, 88, 24));

        nama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                namaKeyTyped(evt);
            }
        });
        jPanel2.add(nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 132, 213, -1));

        tabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabel);

        jPanel2.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(476, 27, 540, 136));

        jenis.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Mawar", "Sakura", "Snapy", "Downy Mistiq", "Downy Passion", "Ocean Fresh", "Lavender ", "Lily", "Aqua Fresh", "Phonix" }));
        jPanel2.add(jenis, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 169, 213, -1));

        berat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beratActionPerformed(evt);
            }
        });
        berat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                beratKeyTyped(evt);
            }
        });
        jPanel2.add(berat, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 206, 213, -1));

        jumlah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jumlahKeyTyped(evt);
            }
        });
        jPanel2.add(jumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 243, 213, -1));

        jLabel2.setText("Jenis Parfum");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 172, -1, -1));

        jLabel13.setText("Berat Pakaian");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 204, -1, 24));

        jLabel14.setText("Jumlah Pakaian");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 242, -1, 22));

        tanggalkeluar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tanggalkeluarKeyReleased(evt);
            }
        });
        jPanel2.add(tanggalkeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 306, 213, -1));

        jamkeluar.setText("Jam Keluar");
        jPanel2.add(jamkeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 347, -1, -1));

        tanggalkeluar1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tanggalkeluar1KeyReleased(evt);
            }
        });
        jPanel2.add(tanggalkeluar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 344, 213, -1));

        lblwktu.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblwktu.setText("jLabel10");
        jPanel2.add(lblwktu, new org.netbeans.lib.awtextra.AbsoluteConstraints(246, 387, -1, -1));

        tglkeluar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tglkeluar.setText("jLabel7");
        jPanel2.add(tglkeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(81, 387, -1, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText(" Tanggal :");
        jLabel10.setToolTipText("");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 387, -1, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("Jam :");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(206, 387, -1, -1));

        jLabel8.setText("Harga");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 275, -1, -1));

        harga.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                hargaKeyReleased(evt);
            }
        });
        jPanel2.add(harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 275, 213, -1));

        jLabel9.setText("Tanggal Keluar");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 309, -1, -1));

        jButton3.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        jButton3.setText("Tambah");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(362, 306, 90, 60));

        jButton5.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        jButton5.setText("PRINT");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 180, 108, 40));

        jButton1.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        jButton1.setText("AMBIL LAUNDRY");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(476, 178, -1, 40));

        tabel1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabel1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabel1);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(477, 230, 540, 141));

        jButton9.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        jButton9.setText("KEMBALI");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 180, 121, 40));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 1023, Short.MAX_VALUE)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(305, 305, 305))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 440, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1023, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 479, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelMouseClicked
        no_antrian.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 0) + "");
        tanggall.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 1) + "");
        jamm.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 2) + "");
        nama.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 3) + "");
        jenis.setSelectedItem(tabmodel.getValueAt(tabel.getSelectedRow(), 4) + "");
        berat.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 5) + "");
        jumlah.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 6) + "");
        harga.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 7) + "");        // TODO add your handling code here:
    }//GEN-LAST:event_tabelMouseClicked

    private void namaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_namaKeyTyped
//        FilterHuruf(evt);        // TODO add your handling code here:
    }//GEN-LAST:event_namaKeyTyped

    private void beratActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beratActionPerformed

    }//GEN-LAST:event_beratActionPerformed

    private void beratKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_beratKeyTyped
//        FilterAngka(evt);
        // TODO add your handling code here:
    }//GEN-LAST:event_beratKeyTyped

    private void jumlahKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jumlahKeyTyped
//        FilterAngka(evt);        // TODO add your handling code here:
    }//GEN-LAST:event_jumlahKeyTyped

    private void hargaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hargaKeyReleased

    }//GEN-LAST:event_hargaKeyReleased

    private void no_antrianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_no_antrianActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_no_antrianActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            stat = con.createStatement();
            stat.executeUpdate("insert into ambil set nomor_antrian='" + no_antrian.getText() + "',tanggal='" + tanggall.getText() + "',jam='" + jamm.getText() + "',nama='" + nama.getText() + "',parfum='" + jenis.getSelectedItem() + "',berat='" + berat.getText() + "',jumlah='" + jumlah.getText() + "',harga='" + harga.getText() + "',tgl_keluar='" + tanggalkeluar.getText() + "',jam_keluar='" + tanggalkeluar1.getText() +"'");
            JOptionPane.showMessageDialog(null, "data berhasil disimpan");
            tampildata1();
            try{
            stat = con.createStatement();
            stat.executeUpdate("delete from transaksi where nomor_antrian = '" + no_antrian.getText() + "'" ); 
            JOptionPane.showMessageDialog(null, "Berhasil");
                 } catch (SQLException | HeadlessException e) { 
 
                    } finally{
                        tampildata();
                     }
            no_antrian.setText("");
            tanggall.setText("");
            jamm.setText("");  
            nama.setText("");
            jenis.setSelectedItem("");
            berat.setText("");
            jumlah.setText("");
            harga.setText(""); 
            tanggalkeluar.setText("");
            tanggalkeluar1.setText("");
    }//GEN-LAST:event_jButton1ActionPerformed
     catch (SQLException | HeadlessException e) {
     }
              
    }
    

    private void tanggalkeluarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tanggalkeluarKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tanggalkeluarKeyReleased

    private void tanggalkeluar1KeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tanggalkeluar1KeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tanggalkeluar1KeyReleased

    private void tabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabel1MouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_tabel1MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        tanggalkeluar1.setText(lblwktu.getText()); 
        tanggalkeluar.setText(tglkeluar.getText());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        new Cetak_transaksi().setVisible(true);        // TODO add your handling code here:
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        new Menuutama().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton9ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ambillaundry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ambillaundry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ambillaundry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ambillaundry.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ambillaundry().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField berat;
    private javax.swing.JTextField harga;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollBar jScrollBar1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel jamkeluar;
    private javax.swing.JTextField jamm;
    private javax.swing.JComboBox jenis;
    private javax.swing.JTextField jumlah;
    private javax.swing.JLabel lblwktu;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField no_antrian;
    private javax.swing.JTable tabel;
    private javax.swing.JTable tabel1;
    private javax.swing.JTextField tanggalkeluar;
    private javax.swing.JTextField tanggalkeluar1;
    private javax.swing.JTextField tanggall;
    private javax.swing.JLabel tglkeluar;
    // End of variables declaration//GEN-END:variables
}
