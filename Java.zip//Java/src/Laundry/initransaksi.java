/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Laundry;

import java.sql.Connection;
import java.sql.Statement;
import java.awt.Dimension;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author annisa
 */
public class initransaksi extends javax.swing.JFrame {
java.util.Date tglsekarang = new java.util.Date();
    private final SimpleDateFormat smpdtfmt = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
    //diatas adalah pengaturan format penulisan, bisa diubah sesuai keinginan.
    private final String tanggal = smpdtfmt.format(tglsekarang);
    private Statement stat;
    private Connection con;
    private ResultSet res;
    public DefaultTableModel tabmodel;
    public long beratt;
    public long jumlahh;
    public long hargaa;
//    private String t;
    private Object displaytext;
   private void koneksi(){
try {
Class.forName("com.mysql.jdbc.Driver");
con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost/laundry", "root", "");
stat=(Statement) con.createStatement();
} catch (ClassNotFoundException | SQLException e) {
JOptionPane.showMessageDialog(null, e);
}
}
    /**
     * Creates new form initransaksi
     */
    public initransaksi() {
        initComponents();
        koneksi();
        judul();
        tampildata();
        no_antrian.disable();
//        tabel();
        kosongkan();
        tgl.setText(tanggal);
        setJam();
//        auto();
        
          
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        Dimension frameSize = getSize();
        setLocation(
        (screenSize.width - frameSize.width) / 2,
        (screenSize.height - frameSize.height) / 2);
    }
    
    
    public final void setJam(){
ActionListener taskPerformer = (ActionEvent evt) -> {
    String nol_jam = "", nol_menit = "",nol_detik = "";
    java.util.Date dateTime = new java.util.Date();
    int nilai_jam = dateTime.getHours();
    int nilai_menit = dateTime.getMinutes();
    int nilai_detik = dateTime.getSeconds();
    if(nilai_jam <= 9) nol_jam= "0";
    if(nilai_menit <= 9) nol_menit= "0";
    if(nilai_detik <= 9) nol_detik= "0";
    String jam = nol_jam + Integer.toString(nilai_jam);
    String menit = nol_menit + Integer.toString(nilai_menit);
    String detik = nol_detik + Integer.toString(nilai_detik);
    lblwktu.setText(jam+":"+menit+":"+detik+"");
};
new Timer(1000, taskPerformer).start();
}

public void tampildata(){
        try {
            stat = con.createStatement();
            tabmodel.getDataVector().removeAllElements();
            tabmodel.fireTableDataChanged();
            res = stat.executeQuery("SELECT * FROM transaksi");
            while (res.next()) {                
                Object[] data = {
                    res.getString("nomor_antrian"),
                    res.getString("tanggal"),
                    res.getString("jam"),
                    res.getString("nama"),
                    res.getString("parfum"),
                    res.getString("berat"),
                    res.getString("jumlah"),
                    res.getString("harga"),};
                tabmodel.addRow(data);
            }
    } catch (Exception e) {
            e.printStackTrace();
    }
    }

private void judul(){ 
        Object[] judul = {"Nomor Antrian","Tanggal","Jam","Nama","Jenis","Berat","Jumlah","Harga"};
        tabmodel = new DefaultTableModel(null,judul);
        tabel.setModel(tabmodel);
}

//public void auto(){
//    Random angka = new Random();
//    String angkaa = String.valueOf(angka.nextInt(999));
//    String kode = "AB"+angkaa;
//    no_antrian.setText(kode);
//    no_antrian.setEnabled(false);
//}
private void kosongkan()
{ 
no_antrian.setText(""); 
tanggall.setText(""); 
jamm.setText(""); 
nama.setText("");
jenis.setSelectedItem(""); 
berat.setText("");
jumlah.setText("");
harga.setText("");
no_antrian.requestFocus();

btnsimpan.setEnabled(true);
btnupdate.setEnabled(false);
btnhapus.setEnabled(false);

}

 public void FilterAngka(KeyEvent b){
        if(Character.isAlphabetic(b.getKeyChar())){
            b.consume();
            JOptionPane.showMessageDialog(null, "Masukkan angka saja", "Peringatan", JOptionPane.WARNING_MESSAGE);
        }
    }
 
  public void FilterHuruf(KeyEvent a){
        if(Character.isDigit(a.getKeyChar())){
            a.consume();
            JOptionPane.showMessageDialog(null, "Masukkan huruf saja", "Peringatan", JOptionPane.WARNING_MESSAGE);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jDialog1 = new javax.swing.JDialog();
        jPanel1 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        javax.swing.JPanel jPanel2 = new javax.swing.JPanel();
        no_antrian = new javax.swing.JTextField();
        tanggall = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        nama = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jamm = new javax.swing.JTextField();
        jumlah = new javax.swing.JTextField();
        jenis = new javax.swing.JComboBox();
        berat = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        harga = new javax.swing.JTextField();
        btnsimpan = new javax.swing.JButton();
        lblwktu = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tgl = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        tcari = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        btnupdate = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabel = new javax.swing.JTable();
        btnhapus = new javax.swing.JButton();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Aplikasi Laundry");
        setBackground(new java.awt.Color(255, 255, 255));
        setPreferredSize(new java.awt.Dimension(934, 532));

        jPanel1.setBackground(new java.awt.Color(153, 153, 255));

        jLabel9.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel9.setText("FORM TRANSAKSI");

        jPanel2.setBackground(new java.awt.Color(255, 153, 153));
        jPanel2.setMaximumSize(new java.awt.Dimension(21474, 2147));
        jPanel2.setMinimumSize(new java.awt.Dimension(1013, 404));
        jPanel2.setPreferredSize(new java.awt.Dimension(534, 476));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel2.add(no_antrian, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 42, 213, -1));
        jPanel2.add(tanggall, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 72, 213, -1));

        jLabel3.setText("Tanggal");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 72, 88, 24));

        jLabel4.setText("Nama");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 137, 88, 20));

        jLabel5.setText("Nomor Antrian");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 42, 88, 24));

        nama.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                namaKeyTyped(evt);
            }
        });
        jPanel2.add(nama, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 137, 213, -1));

        jLabel6.setText("Jam");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 102, 28, 24));
        jPanel2.add(jamm, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 104, 213, -1));

        jumlah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jumlahKeyTyped(evt);
            }
        });
        jPanel2.add(jumlah, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 252, 213, -1));

        jenis.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Mawar", "Sakura", "Snapy", "Downy Mistiq", "Downy Passion", "Ocean Fresh", "Lavender ", "Lily", "Aqua Fresh", "Phonix" }));
        jPanel2.add(jenis, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 174, 213, -1));

        berat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                beratActionPerformed(evt);
            }
        });
        berat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                beratKeyTyped(evt);
            }
        });
        jPanel2.add(berat, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 211, 213, -1));

        jLabel13.setText("Berat Pakaian");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 209, -1, 24));

        jLabel2.setText("Jenis Parfum");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 177, -1, -1));

        jLabel14.setText("Jumlah Pakaian");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 251, -1, 22));

        jButton7.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        jButton7.setText("Hitung");
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 300, -1, -1));

        jLabel8.setText("Harga");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, -1, -1));

        harga.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                hargaKeyReleased(evt);
            }
        });
        jPanel2.add(harga, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 340, 213, -1));

        btnsimpan.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        btnsimpan.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Laundry/gtk-save-as.png"))); // NOI18N
        btnsimpan.setText("SIMPAN");
        btnsimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsimpanActionPerformed(evt);
            }
        });
        jPanel2.add(btnsimpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 220, 121, -1));

        lblwktu.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblwktu.setText("jLabel8");
        jPanel2.add(lblwktu, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 390, -1, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText(" Tanggal :");
        jLabel1.setToolTipText("");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Jam :");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 390, -1, -1));

        tgl.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tgl.setText("jLabel7");
        jPanel2.add(tgl, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 390, -1, -1));

        jButton2.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        jButton2.setText("RESET");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 290, 121, 32));

        jButton9.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        jButton9.setText("KEMBALI");
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 290, 121, 32));

        jButton6.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        jButton6.setText("Tambah");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(362, 72, -1, 49));

        tcari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tcariActionPerformed(evt);
            }
        });
        tcari.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tcariKeyReleased(evt);
            }
        });
        jPanel2.add(tcari, new org.netbeans.lib.awtextra.AbsoluteConstraints(488, 11, 246, -1));

        jLabel10.setText("Cari");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(451, 14, -1, -1));

        btnupdate.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        btnupdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Laundry/gtk-edit.png"))); // NOI18N
        btnupdate.setText("EDIT");
        btnupdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnupdateActionPerformed(evt);
            }
        });
        jPanel2.add(btnupdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 220, 121, -1));

        tabel.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tabel);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 40, 450, 152));

        btnhapus.setFont(new java.awt.Font("Trebuchet MS", 1, 11)); // NOI18N
        btnhapus.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Laundry/document_delete.png"))); // NOI18N
        btnhapus.setText("HAPUS");
        btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhapusActionPerformed(evt);
            }
        });
        jPanel2.add(btnhapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 220, 121, -1));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(370, 370, 370)
                .addComponent(jLabel9)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 933, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 450, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnsimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsimpanActionPerformed
        if (tanggall.getText().equals("")
            || jamm.getText().equals("") || nama.getText().equals("") ||
            jenis.getSelectedItem().equals("") || berat.getText().equals("") ||
            jumlah.getText().equals("") || harga.getText().equals("")) 
        {
          JOptionPane.showMessageDialog(null, "Lengkapi data!");
        }else {
                   try {
            stat = con.createStatement();
            stat.executeUpdate("insert into transaksi set tanggal='" + tanggall.getText() + "',jam='" + jamm.getText() + "',nama='" + nama.getText() + "',parfum='" + jenis.getSelectedItem() + "',berat='" + berat.getText() + "',jumlah='" + jumlah.getText() + "',harga='" + harga.getText() +"'");
            JOptionPane.showMessageDialog(null, "data berhasil disimpan");
            tampildata();
            tanggall.setText("");
            jamm.setText("");  
            nama.setText("");
            jenis.setSelectedItem("");
            berat.setText("");
            jumlah.setText("");
            harga.setText("");
            
        } catch (Exception e) {
            e.printStackTrace();
        
        }
       }
        
    }//GEN-LAST:event_btnsimpanActionPerformed

    private void btnupdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnupdateActionPerformed
        try{
            stat.executeUpdate("update transaksi set "
                + "nomor_antrian='"+no_antrian.getText()+"',"
                + "tanggal='"+tanggall.getText()+"',"
                + "jam='"+jamm.getText()+"',"
                + "nama='"+nama.getText()+"',"
                + "parfum='"+jenis.getSelectedItem()+"',"
                + "berat='"+berat.getText()+"',"
                + "jumlah='"+jumlah.getText()+"',"
                + "harga='"+harga.getText()+"'"

                + " where " + "nomor_antrian='"+no_antrian.getText()+"'" );
            kosongkan();
            JOptionPane.showMessageDialog(rootPane, "Data berhasil Diupdate");
        } catch (SQLException | HeadlessException e) {
            JOptionPane.showMessageDialog(rootPane, e);
        }finally{
         tampildata();
        }
    }//GEN-LAST:event_btnupdateActionPerformed

    private void btnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhapusActionPerformed
         try{
            stat.executeUpdate("delete from transaksi where " + "nomor_antrian='"+no_antrian.getText() +"'" ); 
kosongkan(); 
JOptionPane.showMessageDialog(null, "Berhasil");
 } catch (SQLException | HeadlessException e) { 
JOptionPane.showMessageDialog(null, "pesan salah : "+e);
 } finally{
         tampildata();
          }
    }//GEN-LAST:event_btnhapusActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
//        aktif(true);
//        setTombol(false);
        jamm.setText(lblwktu.getText()); 
        tanggall.setText(tgl.getText());        // TODO add your handling code here:
    }//GEN-LAST:event_jButton6ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
        new Menuutama().setVisible(true);
        dispose();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void tabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelMouseClicked
        // TODO add your handling code here:
        no_antrian.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 0) + "");
        tanggall.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 1) + "");
        jamm.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 2) + "");
        nama.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 3) + "");
        jenis.setSelectedItem(tabmodel.getValueAt(tabel.getSelectedRow(), 4) + "");
        berat.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 5) + "");
        jumlah.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 6) + "");
        harga.setText(tabmodel.getValueAt(tabel.getSelectedRow(), 7) + "");
        
        btnsimpan.setEnabled(false);
        btnupdate.setEnabled(true);
        btnhapus.setEnabled(true);
    }//GEN-LAST:event_tabelMouseClicked

    private void hargaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_hargaKeyReleased
       
    }//GEN-LAST:event_hargaKeyReleased

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed

         beratt = Integer.parseInt(String.valueOf(berat.getText()));
         jumlahh = Integer.parseInt(String.valueOf(jumlah.getText()));
         int hargaa = (int) ((beratt * 7000) );
         harga.setText(String.valueOf(hargaa));   
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        kosongkan();// TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void tcariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tcariActionPerformed
        //         TODO add your handling code here:
    }//GEN-LAST:event_tcariActionPerformed

    private void tcariKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tcariKeyReleased
        // TODO add your handling code here:zz
        try {
            stat = con.createStatement();
            tabmodel.getDataVector().removeAllElements();
            tabmodel.fireTableDataChanged();
            res = stat.executeQuery("select * from transaksi where nomor_antrian like '%" + tcari.getText() + "%' or tanggal like '%" + tcari.getText() + "%' or jam like '%" + tcari.getText() +  "%' or nama like '%" + tcari.getText() +  "%' or parfum like '%" + tcari.getText() +  "%' or berat like '%" + tcari.getText() +  "%' or jumlah like '%" + tcari.getText() +  "%' or harga like '%" + tcari.getText() + "%'");
            while (res.next()) {
                Object[] data = {
                    res.getString("nomor_antrian"),
                    res.getString("tanggal"),
                    res.getString("jam"),
                    res.getString("nama"),
                    res.getString("parfum"),
                    res.getString("berat"),
                    res.getString("jumlah"),
                    res.getString("harga"),};
                tabmodel.addRow(data);
            }
        } catch (Exception e){
            e.printStackTrace();
        }
    }//GEN-LAST:event_tcariKeyReleased

    private void beratActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_beratActionPerformed
        
    }//GEN-LAST:event_beratActionPerformed

    private void beratKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_beratKeyTyped
        FilterAngka(evt);
    // TODO add your handling code here:
    }//GEN-LAST:event_beratKeyTyped

    private void jumlahKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jumlahKeyTyped
        FilterAngka(evt);        // TODO add your handling code here:
    }//GEN-LAST:event_jumlahKeyTyped

    private void namaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_namaKeyTyped
           FilterHuruf(evt);        // TODO add your handling code here:
    }//GEN-LAST:event_namaKeyTyped
    

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(initransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(initransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(initransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(initransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new initransaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField berat;
    private javax.swing.JButton btnhapus;
    private javax.swing.JButton btnsimpan;
    private javax.swing.JButton btnupdate;
    private javax.swing.JTextField harga;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton9;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField jamm;
    private javax.swing.JComboBox jenis;
    private javax.swing.JTextField jumlah;
    private javax.swing.JLabel lblwktu;
    private javax.swing.JTextField nama;
    private javax.swing.JTextField no_antrian;
    private javax.swing.JTable tabel;
    private javax.swing.JTextField tanggall;
    private javax.swing.JTextField tcari;
    private javax.swing.JLabel tgl;
    // End of variables declaration//GEN-END:variables

}
